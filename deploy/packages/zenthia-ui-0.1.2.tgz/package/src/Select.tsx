import {
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type KeyboardEvent,
  type Ref,
  type SelectHTMLAttributes,
} from 'react';
import { createPortal } from 'react-dom';
import { matchesSelection } from './SelectionSearch';
import './select.css';

export interface SelectProps extends Omit<
  SelectHTMLAttributes<HTMLSelectElement>,
  'multiple' | 'size'
> {
  /** La búsqueda está habilitada por defecto en todos los usos. */
  searchable?: boolean;
  columns?: readonly [string, string];
  ref?: Ref<HTMLSelectElement>;
}

/** Conserva el select real como control de formulario y ofrece un menú buscable. */
export function Select({
  searchable = true,
  columns,
  ref,
  onChange,
  onKeyDown,
  onPointerDown,
  onMouseDown,
  onBlur,
  ...props
}: SelectProps) {
  const generatedId = useId();
  const popupId = `${generatedId}-popup`;
  const listId = `${generatedId}-list`;
  const select = useRef<HTMLSelectElement>(null);
  const popup = useRef<HTMLDivElement>(null);
  const searchInput = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [active, setActive] = useState(0);
  const options = open
    ? Array.from(select.current?.options ?? []).filter(
        (option) =>
          !option.hidden &&
          matchesSelection(
            `${option.text} ${option.dataset.search ?? option.value} ${option.dataset.secondary ?? ''}`,
            search,
          ),
      )
    : [];
  const enabled = options.filter((option) => !option.disabled);
  const activeOption =
    enabled[Math.min(active, Math.max(enabled.length - 1, 0))];
  const activeId = activeOption
    ? `${listId}-${options.indexOf(activeOption)}`
    : undefined;

  function close(restoreFocus = false) {
    setOpen(false);
    if (restoreFocus) select.current?.focus();
  }
  function show(initialSearch = '') {
    const element = select.current;
    if (!element || element.matches(':disabled')) return;
    setSearch(initialSearch);
    const selected = Array.from(element.options)
      .filter((option) => !option.hidden && !option.disabled)
      .findIndex((option) => option.selected);
    setActive(initialSearch ? 0 : Math.max(0, selected));
    setOpen(true);
  }
  function choose(option: HTMLOptionElement) {
    const element = select.current;
    if (!element || element.matches(':disabled') || option.disabled) return;
    element.value = option.value;
    element.dispatchEvent(new Event('change', { bubbles: true }));
    close(true);
  }
  function navigate(event: KeyboardEvent<HTMLElement>) {
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      close(true);
    } else if (event.key === 'Tab') {
      // Volver al control antes del movimiento nativo conserva el orden del formulario.
      close(true);
    } else if (event.key === 'Enter' || (event.key === ' ' && !searchable)) {
      event.preventDefault();
      if (activeOption) choose(activeOption);
    } else if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      setActive((index) =>
        Math.max(
          0,
          Math.min(
            enabled.length - 1,
            index + (event.key === 'ArrowDown' ? 1 : -1),
          ),
        ),
      );
    } else if (!searchable && (event.key === 'Home' || event.key === 'End')) {
      event.preventDefault();
      setActive(event.key === 'Home' ? 0 : Math.max(0, enabled.length - 1));
    }
  }

  useLayoutEffect(() => {
    if (!open) return;
    const element = select.current!;
    const menu = popup.current!;
    if (element.matches(':disabled')) {
      setOpen(false);
      return;
    }
    // Popover presenta el menú sobre los dialog nativos; el control conserva su formulario.
    menu.showPopover?.();
    function position() {
      const rect = element.getBoundingClientRect();
      const viewport = window.visualViewport;
      const height = viewport?.height ?? window.innerHeight;
      const width = viewport?.width ?? window.innerWidth;
      const spaceBelow = height - rect.bottom - 8;
      const above = spaceBelow < 200 && rect.top > spaceBelow;
      const maxHeight = Math.max(
        80,
        Math.min(340, above ? rect.top - 8 : spaceBelow),
      );
      const menuWidth = Math.min(
        Math.max(rect.width, columns ? 440 : 240),
        width - 16,
      );
      menu.style.width = `${menuWidth}px`;
      menu.style.font = window.getComputedStyle(element).font;
      menu.style.maxHeight = `${maxHeight}px`;
      menu.style.left = `${Math.max(8, Math.min(rect.left, width - menuWidth - 8))}px`;
      menu.style.top = `${above ? Math.max(8, rect.top - Math.min(menu.scrollHeight, maxHeight) - 4) : rect.bottom + 4}px`;
    }
    position();
    (searchable
      ? searchInput.current
      : menu.querySelector<HTMLElement>('[role="listbox"]')
    )?.focus({ preventScroll: true });
    function outside(event: PointerEvent) {
      if (
        event.target instanceof Node &&
        !menu.contains(event.target) &&
        event.target !== element
      )
        setOpen(false);
    }
    document.addEventListener('pointerdown', outside, true);
    window.addEventListener('resize', position);
    window.addEventListener('scroll', position, true);
    window.visualViewport?.addEventListener('resize', position);
    window.visualViewport?.addEventListener('scroll', position);
    return () => {
      menu.hidePopover?.();
      document.removeEventListener('pointerdown', outside, true);
      window.removeEventListener('resize', position);
      window.removeEventListener('scroll', position, true);
      window.visualViewport?.removeEventListener('resize', position);
      window.visualViewport?.removeEventListener('scroll', position);
    };
  }, [open, searchable, columns]);

  useLayoutEffect(() => {
    if (open && select.current?.matches(':disabled')) setOpen(false);
  });

  useLayoutEffect(() => {
    if (open && activeId)
      document.getElementById(activeId)?.scrollIntoView?.({ block: 'nearest' });
  }, [open, activeId]);

  return (
    <>
      <select
        {...props}
        className={`searchable-select ${props.className ?? ''}`}
        ref={(element) => {
          select.current = element;
          if (typeof ref === 'function') return ref(element);
          if (ref) ref.current = element;
        }}
        aria-expanded={open}
        aria-controls={open ? listId : undefined}
        aria-haspopup="listbox"
        onPointerDown={(event) => {
          onPointerDown?.(event);
          if (event.defaultPrevented || event.button !== 0) return;
          event.preventDefault();
          event.currentTarget.focus();
          if (open) close();
          else show();
        }}
        onMouseDown={(event) => {
          onMouseDown?.(event);
          event.preventDefault();
        }}
        onKeyDown={(event) => {
          onKeyDown?.(event);
          if (event.defaultPrevented) return;
          if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(event.key)) {
            event.preventDefault();
            show();
          } else if (
            searchable &&
            event.key.length === 1 &&
            !event.ctrlKey &&
            !event.altKey &&
            !event.metaKey
          ) {
            event.preventDefault();
            show(event.key);
          }
        }}
        onChange={(event) => {
          onChange?.(event);
          setOpen(false);
        }}
        onBlur={onBlur}
      />
      {open &&
        createPortal(
          <div
            id={popupId}
            ref={popup}
            popover={
              typeof HTMLElement.prototype.showPopover === 'function'
                ? 'manual'
                : undefined
            }
            className="select-popup"
            tabIndex={-1}
            onKeyDown={navigate}
            onBlur={(event) => {
              if (
                !event.currentTarget.contains(
                  event.relatedTarget as Node | null,
                )
              )
                close();
            }}
          >
            {searchable && (
              <div className="select-search">
                <input
                  ref={searchInput}
                  type="search"
                  aria-label="Buscar opciones"
                  placeholder="Buscar…"
                  role="combobox"
                  aria-expanded="true"
                  aria-controls={listId}
                  aria-activedescendant={activeId}
                  aria-autocomplete="list"
                  value={search}
                  onChange={(event) => {
                    setSearch(event.target.value);
                    setActive(0);
                  }}
                />
                <button
                  type="button"
                  aria-label="Limpiar búsqueda"
                  disabled={!search}
                  onClick={() => {
                    setSearch('');
                    setActive(0);
                    searchInput.current?.focus();
                  }}
                >
                  ×
                </button>
              </div>
            )}
            {columns && (
              <div className="select-columns" aria-hidden="true">
                <span>{columns[0]}</span>
                <span>{columns[1]}</span>
              </div>
            )}
            <div
              id={listId}
              role="listbox"
              tabIndex={!searchable ? -1 : undefined}
              aria-label="Opciones disponibles"
              aria-activedescendant={!searchable ? activeId : undefined}
            >
              {options.map((option, index) => (
                <div
                  id={`${listId}-${index}`}
                  key={`${option.value}-${index}`}
                  role="option"
                  aria-selected={option.selected}
                  aria-disabled={option.disabled || undefined}
                  className={`select-option${columns ? ' select-columns' : ''}${option === activeOption ? ' select-option-active' : ''}`}
                  onPointerDown={(event) => event.preventDefault()}
                  onClick={() => choose(option)}
                  onPointerMove={() => {
                    if (!option.disabled) setActive(enabled.indexOf(option));
                  }}
                >
                  <span>{option.text}</span>
                  {columns && <span>{option.dataset.secondary ?? '—'}</span>}
                </div>
              ))}
            </div>
            {!options.length && (
              <div className="select-empty" role="status">
                Sin coincidencias
              </div>
            )}
          </div>,
          select.current?.closest('dialog') ?? document.body,
        )}
    </>
  );
}
