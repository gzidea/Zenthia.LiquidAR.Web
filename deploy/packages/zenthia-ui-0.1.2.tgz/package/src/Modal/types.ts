import type { ReactNode, RefObject } from 'react';
import type { ButtonProps } from '../Button';

export type ModalCloseReason =
  'cancel' | 'close-button' | 'escape' | 'backdrop' | 'native';
export interface ModalButtonOptions {
  radius?: ButtonProps['radius'];
  label?: string;
  disabled?: boolean;
  loading?: boolean;
  loadingLabel?: string;
  icon?: ReactNode;
  display?: 'icon' | 'icon-text' | 'text';
}
export interface ModalAcceptButtonOptions extends ModalButtonOptions {
  type?: 'button' | 'submit';
  form?: string;
}
export type ModalFooter =
  { type: 'standard' } | { type: 'custom'; content: ReactNode } | null;

interface CommonProps {
  open: boolean;
  className?: string;
  children?: ReactNode;
  titleIcon?: ReactNode;
  subtitle?: ReactNode;
  onClose: (reason: ModalCloseReason) => void;
  /** Consumer handles async state, errors and closing after success. Ignored for submit buttons. */
  onAccept?: () => void | Promise<void>;
  /** Replaces the default cancel close request. */
  onCancel?: () => void;
  acceptButton?: boolean | ModalAcceptButtonOptions;
  cancelButton?: boolean | ModalButtonOptions;
  footer?: ModalFooter;
  /** Extra content on the left of the standard footer. */
  actions?: ReactNode;
  size?: 'small' | 'medium' | 'large';
  fullWidth?: boolean;
  showCloseButton?: boolean;
  closeDisabled?: boolean;
  disableEscapeClose?: boolean;
  disableBackdropClose?: boolean;
  initialFocusRef?: RefObject<HTMLElement | null>;
  ariaDescribedBy?: string;
}
// A visible title or an explicit accessible name is always required.
export type ModalProps = CommonProps &
  (
    | {
        title: Exclude<ReactNode, null | undefined | boolean>;
        ariaLabel?: string;
      }
    | { title?: ReactNode; ariaLabel: string }
  );
