export { Modal } from './Modal';
export type {
  ModalProps,
  ModalFooter,
  ModalButtonOptions,
  ModalAcceptButtonOptions,
  ModalCloseReason,
} from './types';
