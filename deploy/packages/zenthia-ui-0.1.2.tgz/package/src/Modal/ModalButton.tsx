import { Button } from '../Button';
import type { ModalAcceptButtonOptions } from './types';

export function ModalButton({
  label,
  options,
  variant,
  disabled,
  onClick,
}: {
  label: string;
  options: ModalAcceptButtonOptions;
  variant: 'primary' | 'ghost';
  disabled?: boolean;
  onClick?: () => void;
}) {
  const text = options.label ?? label;
  const display = options.display ?? (options.icon ? 'icon-text' : 'text');
  const iconOnly =
    display === 'icon' && Boolean(options.icon) && !options.loading;
  return (
    <Button
      variant={variant}
      radius={options.radius}
      type={options.type ?? 'button'}
      form={options.form}
      disabled={disabled || options.disabled}
      busy={options.loading}
      aria-label={text}
      title={iconOnly ? text : undefined}
      className={iconOnly ? 'modal-icon-button' : undefined}
      onClick={onClick}
    >
      {options.loading ? (
        <>
          <span className="modal-spinner" aria-hidden="true" />
          <span role="status">{options.loadingLabel ?? 'Procesando…'}</span>
        </>
      ) : (
        <>
          {display !== 'text' && options.icon && (
            <span className="modal-button-icon" aria-hidden="true">
              {options.icon}
            </span>
          )}
          {!iconOnly && text}
        </>
      )}
    </Button>
  );
}
