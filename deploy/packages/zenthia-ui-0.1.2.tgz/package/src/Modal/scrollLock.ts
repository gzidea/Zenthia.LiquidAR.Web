const locks = new WeakMap<Document, { count: number; restore: () => void }>();

/** Shared by native modals so closing a nested dialog cannot unlock its parent. */
export function lockPageScroll(document: Document): () => void {
  let lock = locks.get(document);
  if (!lock) {
    const saved = [document.documentElement, document.body].map((element) => ({
      element,
      value: element.style.getPropertyValue('overflow'),
      priority: element.style.getPropertyPriority('overflow'),
    }));
    saved.forEach(({ element }) =>
      element.style.setProperty('overflow', 'hidden'),
    );
    lock = {
      count: 0,
      restore: () =>
        saved.forEach(({ element, value, priority }) => {
          if (value) element.style.setProperty('overflow', value, priority);
          else element.style.removeProperty('overflow');
        }),
    };
    locks.set(document, lock);
  }
  lock.count++;
  let released = false;
  return () => {
    if (released) return;
    released = true;
    if (--lock.count === 0) {
      lock.restore();
      locks.delete(document);
    }
  };
}
