import {
  useId,
  useLayoutEffect,
  useRef,
  type MouseEvent,
  type PointerEvent,
} from 'react';
import { createPortal } from 'react-dom';
import { Button } from '../Button';
import { Icon } from '../Icon';
import { ModalButton } from './ModalButton';
import { lockPageScroll } from './scrollLock';
import type { ModalCloseReason, ModalProps } from './types';
import './modal.css';

function outside(
  event: MouseEvent<HTMLDialogElement> | PointerEvent<HTMLDialogElement>,
) {
  const rect = event.currentTarget.getBoundingClientRect();
  return (
    event.target === event.currentTarget &&
    (event.clientX < rect.left ||
      event.clientX > rect.right ||
      event.clientY < rect.top ||
      event.clientY > rect.bottom)
  );
}

export function Modal({
  open,
  className = '',
  title,
  titleIcon,
  subtitle,
  ariaLabel,
  ariaDescribedBy,
  children,
  onClose,
  onCancel,
  onAccept,
  acceptButton,
  cancelButton = true,
  footer,
  actions,
  size = 'medium',
  fullWidth = false,
  showCloseButton = true,
  closeDisabled = false,
  disableEscapeClose = false,
  disableBackdropClose = false,
  initialFocusRef,
}: ModalProps) {
  const titleId = useId();
  const subtitleId = useId();
  const dialog = useRef<HTMLDialogElement>(null);
  const heading = useRef<HTMLDivElement>(null);
  const body = useRef<HTMLDivElement>(null);
  const backdropPress = useRef(false);
  const hasTitle =
    title !== undefined &&
    title !== null &&
    typeof title !== 'boolean' &&
    title !== '';
  const accept = typeof acceptButton === 'object' ? acceptButton : {};
  const hasSubtitle =
    hasTitle &&
    subtitle !== undefined &&
    subtitle !== null &&
    typeof subtitle !== 'boolean' &&
    subtitle !== '';
  const cancel = typeof cancelButton === 'object' ? cancelButton : {};
  const hasAccept =
    acceptButton !== false && (Boolean(acceptButton) || Boolean(onAccept));
  const hasStandardFooter = footer === undefined || footer?.type === 'standard';
  const hasFooter = hasStandardFooter
    ? Boolean(cancelButton || hasAccept || actions)
    : footer?.type === 'custom' && footer.content != null;

  useLayoutEffect(() => {
    const element = dialog.current;
    if (!open || !element) return;
    const trigger = element.ownerDocument.activeElement;
    element.showModal();
    const unlock = lockPageScroll(element.ownerDocument);
    const target = initialFocusRef?.current;
    if (target && element.contains(target))
      target.focus({ preventScroll: true });
    else (heading.current ?? body.current)?.focus({ preventScroll: true });
    return () => {
      backdropPress.current = false;
      element.close();
      unlock();
      if (trigger instanceof HTMLElement && trigger.isConnected)
        trigger.focus({ preventScroll: true });
    };
  }, [open, initialFocusRef]);

  function requestClose(reason: ModalCloseReason) {
    if (!closeDisabled) onClose(reason);
  }
  if (!open) return null;
  const closeButton = showCloseButton ? (
    <Button
      variant="ghost"
      className="modal-close modal-icon-button"
      aria-label="Cerrar modal"
      title="Cerrar"
      disabled={closeDisabled}
      onClick={() => requestClose('close-button')}
    >
      <Icon name="close" />
    </Button>
  ) : null;

  return createPortal(
    <dialog
      ref={dialog}
      className={`modal-dialog modal-${size}${fullWidth ? ' modal-full-width' : ''}${!hasTitle && showCloseButton ? ' modal-untitled' : ''} ${className}`}
      aria-modal="true"
      aria-labelledby={hasTitle ? titleId : undefined}
      aria-label={hasTitle ? undefined : ariaLabel}
      aria-describedby={
        [ariaDescribedBy, hasSubtitle ? subtitleId : undefined]
          .filter(Boolean)
          .join(' ') || undefined
      }
      onCancel={(event) => {
        event.preventDefault();
        event.stopPropagation();
        if (!disableEscapeClose) requestClose('escape');
      }}
      onClose={(event) => {
        event.stopPropagation();
        // Native form method="dialog" or an imperative close must not override controlled open.
        if (
          open &&
          !event.currentTarget.open &&
          event.currentTarget.isConnected
        ) {
          event.currentTarget.showModal();
          requestClose('native');
        }
      }}
      onPointerDown={(event) => {
        backdropPress.current = outside(event);
      }}
      onPointerCancel={() => {
        backdropPress.current = false;
      }}
      onClick={(event) => {
        const dismiss = backdropPress.current && outside(event);
        backdropPress.current = false;
        if (dismiss && !disableBackdropClose) requestClose('backdrop');
      }}
    >
      {hasTitle && (
        <header
          className={`modal-header${titleIcon ? ' modal-header-has-icon' : ''}${hasSubtitle ? ' modal-header-with-subtitle' : ''}`}
        >
          {titleIcon && (
            <span className="modal-title-icon" aria-hidden="true">
              {titleIcon}
            </span>
          )}
          <div
            ref={heading}
            id={titleId}
            className="modal-title"
            tabIndex={-1}
            title={typeof title === 'string' ? title : undefined}
          >
            {title}
          </div>
          {hasSubtitle && (
            <div id={subtitleId} className="modal-subtitle">
              {subtitle}
            </div>
          )}
          {closeButton}
        </header>
      )}
      {!hasTitle && closeButton}
      <div ref={body} className="modal-body" tabIndex={-1}>
        {children}
      </div>
      {hasFooter && (
        <footer
          className={`modal-footer${hasStandardFooter ? ' modal-footer-standard' : ''}`}
        >
          {hasStandardFooter ? (
            <>
              {actions && <div className="modal-extra-actions">{actions}</div>}
              <div className="modal-standard-actions">
                {cancelButton && (
                  <ModalButton
                    label="Cancelar"
                    options={cancel}
                    variant="ghost"
                    disabled={closeDisabled}
                    onClick={() => {
                      if (onCancel) onCancel();
                      else requestClose('cancel');
                    }}
                  />
                )}
                {hasAccept && (
                  <ModalButton
                    label="Aceptar"
                    options={accept}
                    variant="primary"
                    onClick={
                      accept.type === 'submit'
                        ? undefined
                        : () => {
                            void onAccept?.();
                          }
                    }
                  />
                )}
              </div>
            </>
          ) : footer?.type === 'custom' ? (
            footer.content
          ) : null}
        </footer>
      )}
    </dialog>,
    document.body,
  );
}
