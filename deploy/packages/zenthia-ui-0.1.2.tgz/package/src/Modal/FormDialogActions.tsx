import { Button } from '../Button';

export type SaveDestination = 'stay' | 'close' | 'new';

/** Submit buttons use the same form validation as the primary Save and close. */
export function FormDialogActions({
  form,
  busy,
  loading,
  hasError,
  onUndo,
  allowNew = true,
}: {
  form: string;
  busy: boolean;
  loading: boolean;
  hasError: boolean;
  onUndo: () => void;
  allowNew?: boolean;
}) {
  return (
    <>
      <Button
        variant="ghost"
        type="submit"
        form={form}
        value="stay"
        disabled={busy || loading || hasError}
      >
        Guardar
      </Button>
      {allowNew && (
        <Button
          variant="ghost"
          type="submit"
          form={form}
          value="new"
          disabled={busy || loading || hasError}
        >
          Guardar y nuevo
        </Button>
      )}
      <Button variant="ghost" disabled={busy || loading} onClick={onUndo}>
        Deshacer
      </Button>
    </>
  );
}

export function getSaveDestination(
  submitter: HTMLElement | null,
): SaveDestination {
  const value = submitter instanceof HTMLButtonElement ? submitter.value : '';
  return value === 'stay' || value === 'new' ? value : 'close';
}
