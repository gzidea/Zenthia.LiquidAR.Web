import { useEffect, useState } from 'react';
import type { DataGridColumn, DataGridColumnWidthsModel } from './types';

export function columnBounds<T>(column: DataGridColumn<T>) {
  const min = Math.max(32, column.minWidth ?? 120);
  return { min, max: Math.max(min, column.maxWidth ?? 10000) };
}

export function useColumnLayout<T>(
  columns: readonly DataGridColumn<T>[],
  model: DataGridColumnWidthsModel,
  reserved: number,
) {
  const [container, setContainer] = useState<HTMLDivElement | null>(null);
  const [available, setAvailable] = useState(0);
  useEffect(() => {
    const element = container;
    if (!element || typeof ResizeObserver === 'undefined') return;
    const observer = new ResizeObserver(([entry]) => {
      if (entry) setAvailable(entry.contentRect.width);
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, [container]);
  const widths = columns.map((column) => {
    const { min, max } = columnBounds(column);
    return Math.max(
      min,
      Math.min(max, model[column.field] ?? column.width ?? 180),
    );
  });
  let remaining = available - reserved - widths.reduce((a, b) => a + b, 0);
  let flexible = columns
    .map((column, index) => ({ column, index }))
    .filter(
      ({ column, index }) =>
        model[column.field] === undefined &&
        column.width === undefined &&
        widths[index]! < columnBounds(column).max,
    );
  while (remaining > 0.5 && flexible.length) {
    const share = remaining / flexible.length;
    for (const { column, index } of flexible) {
      const extra = Math.min(share, columnBounds(column).max - widths[index]!);
      widths[index]! += extra;
      remaining -= extra;
    }
    flexible = flexible.filter(
      ({ column, index }) => widths[index]! < columnBounds(column).max,
    );
  }
  return {
    container: setContainer,
    widths,
    tableWidth: reserved + widths.reduce((a, b) => a + b, 0),
  };
}
