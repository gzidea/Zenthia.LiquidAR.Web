import { Select } from '../Select';
import {
  useId,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type MouseEvent,
  type CSSProperties,
} from 'react';
import { Icon } from '../Icon';
import { Button } from '../Button';
import { Input } from '../Input';
import { Notice } from '../Notice';
import { DataGridSkeletonRows } from '../Skeleton';
import { operatorsFor, processRows } from './model';
import { ActionButton } from './ActionButton';
import { ColumnResizeHandle } from './ColumnResizeHandle';
import { columnBounds, useColumnLayout } from './useColumnLayout';
import type {
  DataGridProps,
  DataGridRowId,
  DataGridSelectionContext,
  DataGridSelectionModel,
  DataGridState,
} from './types';
import './data-grid.css';

function useModel<T>(
  controlled: T | undefined,
  initial: T,
  onChange?: (value: T) => void,
): [T, (value: T) => void] {
  const [internal, setInternal] = useState(initial);
  return [
    controlled === undefined ? internal : controlled,
    (value: T) => {
      if (controlled === undefined) setInternal(value);
      onChange?.(value);
    },
  ];
}
const emptySelection: DataGridSelectionModel = { type: 'include', ids: [] };
const defaults: DataGridState = {
  pagination: { page: 0, pageSize: 25 },
  sort: null,
  filters: [],
  search: '',
  selection: emptySelection,
  columnVisibility: {},
  columnOrder: [],
  columnWidths: {},
};

export function DataGrid<T>(props: DataGridProps<T>) {
  const {
    rows,
    columns,
    getRowId,
    loading = false,
    error,
    label,
    initialState,
    selectionMode = 'none',
    checkboxSelection = true,
    selectOnClick = true,
    selectOnKeyboard = true,
    selectAll = 'page',
  } = props;
  const id = useId();
  const [pagination, setPagination] = useModel(
    props.paginationModel,
    initialState?.pagination ?? defaults.pagination,
    props.onPaginationModelChange,
  );
  const [sort, setSort] = useModel(
    props.sortModel,
    initialState?.sort ?? defaults.sort,
    props.onSortModelChange,
  );
  const [filters, setFilters] = useModel(
    props.filterModel,
    initialState?.filters ?? defaults.filters,
    props.onFilterModelChange,
  );
  const [search, setSearch] = useModel(
    props.search,
    initialState?.search ?? defaults.search,
    props.onSearchChange,
  );
  const [selection, setSelection] = useModel(
    props.selectionModel,
    initialState?.selection ?? defaults.selection,
    props.onSelectionModelChange,
  );
  const [visibility, setVisibility] = useModel(
    props.columnVisibilityModel,
    initialState?.columnVisibility ?? defaults.columnVisibility,
    props.onColumnVisibilityModelChange,
  );
  const [order, setOrder] = useModel(
    props.columnOrder,
    initialState?.columnOrder ?? defaults.columnOrder,
    props.onColumnOrderChange,
  );
  const [showFilters, setShowFilters] = useState(false);
  const [columnWidths, setColumnWidths] = useModel(
    props.columnWidthsModel,
    initialState?.columnWidths ?? defaults.columnWidths,
    props.onColumnWidthsModelChange,
  );
  const [resizePreview, setResizePreview] = useState<{
    field: string;
    width: number;
  } | null>(null);
  const [showColumns, setShowColumns] = useState(false);
  const anchor = useRef<DataGridRowId | null>(null);
  const dragged = useRef<string | null>(null);
  const body = useRef<HTMLTableSectionElement>(null);
  const remote = props.processingMode === 'server';
  const scope = props.selectionScope ?? 'local';
  const activeSelection =
    selectionMode === 'none' ||
    (selection.type === 'all' && selection.scope !== scope)
      ? emptySelection
      : selection;
  const selectionIds = useMemo(
    () =>
      new Set(
        activeSelection.type === 'include'
          ? activeSelection.ids
          : activeSelection.excludedIds,
      ),
    [activeSelection],
  );
  const canSelectId = (rowId: DataGridRowId) => {
    const row = rows.find((r) => getRowId(r) === rowId);
    return !row || props.isRowSelectable?.(row) !== false;
  };
  const selected = (rowId: DataGridRowId) =>
    canSelectId(rowId) &&
    (activeSelection.type === 'include'
      ? selectionIds.has(rowId)
      : !selectionIds.has(rowId));
  const processed = useMemo(
    () => (remote ? rows : processRows(rows, columns, search, filters, sort)),
    [remote, rows, columns, search, filters, sort],
  );
  const total = remote ? props.rowCount : processed.length;
  const pageSize = Math.max(1, Math.floor(pagination.pageSize) || 25);
  const lastPage = Math.max(0, Math.ceil(total / pageSize) - 1);
  const page = Math.max(
    0,
    Math.min(Math.floor(pagination.page) || 0, lastPage),
  );
  const pageRows = remote
    ? rows
    : processed.slice(page * pageSize, (page + 1) * pageSize);
  const pageIds = pageRows.map(getRowId);
  const selectableIds = pageIds.filter(canSelectId);
  const orderedColumns = [
    ...new Set([...order, ...columns.map((c) => c.field)]),
  ].flatMap((field) => columns.filter((c) => c.field === field));
  const visibleColumns = orderedColumns.filter(
    (c) => c.hideable === false || (visibility[c.field] ?? !c.initiallyHidden),
  );
  const hasCheckbox = selectionMode !== 'none' && checkboxSelection;
  const hasActions = Boolean(props.rowActions?.length);
  const actionWidth = Math.max(
    120,
    (props.rowActions ?? []).reduce(
      (width, action) =>
        width + (action.display === 'icon' && action.icon ? 40 : 104),
      24,
    ),
  );
  const layout = useColumnLayout(
    visibleColumns,
    resizePreview
      ? { ...columnWidths, [resizePreview.field]: resizePreview.width }
      : columnWidths,
    (hasCheckbox ? 52 : 0) + (hasActions ? actionWidth : 0),
  );
  const selectionContext: DataGridSelectionContext<T> = {
    model: activeSelection,
    loadedRows: rows.filter((row) => selected(getRowId(row))),
    count:
      activeSelection.type === 'include'
        ? activeSelection.ids.filter(canSelectId).length
        : Math.max(0, total - activeSelection.excludedIds.length),
  };
  const disabled = loading || Boolean(error);
  const allPageSelected =
    selectableIds.length > 0 && selectableIds.every(selected);
  const somePageSelected = selectableIds.some(selected);
  const pageSizes = [
    ...new Set([...(props.pageSizeOptions ?? [10, 25, 50, 100]), pageSize]),
  ]
    .filter((n) => Number.isInteger(n) && n > 0)
    .sort((a, b) => a - b);
  const canSelectDataset =
    !props.isRowSelectable &&
    selectAll === 'dataset' &&
    (!remote || Boolean(props.selectionScope));

  function resetQuery() {
    if (pagination.page !== 0) setPagination({ page: 0, pageSize });
    anchor.current = null;
    if (
      selectionMode !== 'none' &&
      !(
        props.keepSelectionOnQueryChange &&
        !remote &&
        activeSelection.type === 'include'
      )
    )
      setSelection(emptySelection);
  }
  function changeIds(ids: readonly DataGridRowId[], checked: boolean) {
    if (checked) ids = ids.filter(canSelectId);
    if (activeSelection.type === 'all') {
      const excluded = new Set(activeSelection.excludedIds);
      ids.forEach((rowId) =>
        checked ? excluded.delete(rowId) : excluded.add(rowId),
      );
      setSelection({ ...activeSelection, excludedIds: [...excluded] });
    } else {
      const next = new Set(activeSelection.ids.filter(canSelectId));
      ids.forEach((rowId) => (checked ? next.add(rowId) : next.delete(rowId)));
      setSelection({ type: 'include', ids: [...next] });
    }
  }
  function selectRow(
    rowId: DataGridRowId,
    event: Pick<MouseEvent, 'shiftKey' | 'ctrlKey' | 'metaKey'>,
    checkbox = false,
  ) {
    if (selectionMode === 'none' || disabled || !canSelectId(rowId)) return;
    if (selectionMode === 'single') {
      setSelection({ type: 'include', ids: selected(rowId) ? [] : [rowId] });
    } else if (
      event.shiftKey &&
      anchor.current !== null &&
      pageIds.includes(anchor.current)
    ) {
      const start = pageIds.indexOf(anchor.current);
      const end = pageIds.indexOf(rowId);
      changeIds(
        pageIds.slice(Math.min(start, end), Math.max(start, end) + 1),
        true,
      );
      return;
    } else if (event.ctrlKey || event.metaKey || checkbox) {
      changeIds([rowId], !selected(rowId));
    } else {
      setSelection({ type: 'include', ids: [rowId] });
    }
    anchor.current = rowId;
  }
  function rowKeyDown(
    event: KeyboardEvent<HTMLTableRowElement>,
    rowId: DataGridRowId,
    index: number,
  ) {
    if (event.target !== event.currentTarget || !selectOnKeyboard) return;
    if (event.key === ' ' || event.key === 'Enter') {
      event.preventDefault();
      selectRow(rowId, event, true);
    }
    const next =
      event.key === 'ArrowDown'
        ? index + 1
        : event.key === 'ArrowUp'
          ? index - 1
          : event.key === 'Home'
            ? 0
            : event.key === 'End'
              ? pageRows.length - 1
              : null;
    if (next !== null) {
      event.preventDefault();
      const bounded = Math.max(0, Math.min(next, pageRows.length - 1));
      body.current?.rows[bounded]?.focus();
      const nextId = pageIds[bounded];
      if (event.shiftKey && nextId !== undefined) {
        anchor.current ??= rowId;
        selectRow(nextId, event);
      }
    }
  }
  function moveColumn(field: string, target: string) {
    const fields = orderedColumns.map((c) => c.field);
    const from = fields.indexOf(field);
    const to = fields.indexOf(target);
    if (from < 0 || to < 0 || from === to) return;
    fields.splice(from, 1);
    fields.splice(to, 0, field);
    setOrder(fields);
  }

  return (
    <section
      className="data-grid"
      aria-label={label}
      aria-busy={loading}
      style={
        {
          '--data-grid-row-height': `${Math.max(32, props.rowHeight ?? 48)}px`,
        } as CSSProperties
      }
    >
      <div className="data-grid-toolbar">
        {props.globalActions
          ?.filter((a) => a.visible !== false)
          .map((a) => (
            <ActionButton key={a.id} {...a} />
          ))}
        {props.showFilterButton !== false && (
          <Button
            variant="ghost"
            className="data-grid-icon-button"
            aria-label="Filtros"
            title={props.filtersUnavailableReason ?? 'Filtros'}
            disabled={props.filterButtonDisabled}
            aria-expanded={showFilters}
            aria-controls={`${id}-filters`}
            onClick={() => setShowFilters(!showFilters)}
          >
            <Icon name="filter" />
          </Button>
        )}
        <Button
          variant="ghost"
          className="data-grid-icon-button"
          aria-label="Columnas"
          title="Columnas"
          aria-expanded={showColumns}
          aria-controls={`${id}-columns`}
          onClick={() => setShowColumns(!showColumns)}
        >
          <Icon name="columns" />
        </Button>
        {props.showSearch !== false && (
          <div className="data-grid-search">
            <Icon name="search" />
            <input
              type="search"
              disabled={props.searchDisabled}
              title={props.searchUnavailableReason}
              aria-label={`Buscar en ${label}`}
              placeholder="Buscar…"
              value={search}
              onChange={(event) => {
                setSearch(event.target.value);
                resetQuery();
              }}
            />
          </div>
        )}
      </div>
      {props.showFilterButton !== false && showFilters && (
        <fieldset id={`${id}-filters`} className="data-grid-panel">
          <legend>Filtros por columna</legend>
          {columns
            .filter((c) => c.filterable !== false && operatorsFor(c).length > 0)
            .map((column) => {
              const operators = operatorsFor(column);
              const filter = filters.find((f) => f.field === column.field) ?? {
                field: column.field,
                operator: operators[0]!.value,
                value: '',
              };
              const update = (value: string, operator = filter.operator) => {
                setFilters([
                  ...filters.filter((f) => f.field !== column.field),
                  { ...filter, operator, value },
                ]);
                resetQuery();
              };
              return (
                <div className="data-grid-filter" key={column.field}>
                  <label>
                    {`Operador de ${column.header}`}
                    <Select
                      value={filter.operator}
                      onChange={(e) => update(filter.value, e.target.value)}
                    >
                      {operators.map((o) => (
                        <option key={o.value} value={o.value}>
                          {o.label}
                        </option>
                      ))}
                    </Select>
                  </label>
                  {column.renderFilter ? (
                    column.renderFilter(filter, (value) => update(value))
                  ) : column.type === 'boolean' || column.type === 'select' ? (
                    <label>
                      {`Filtrar ${column.header}`}
                      <Select
                        value={filter.value}
                        onChange={(e) => update(e.target.value)}
                      >
                        <option value="">Todos</option>
                        {(column.type === 'boolean'
                          ? [
                              { value: 'true', label: 'Sí' },
                              { value: 'false', label: 'No' },
                            ]
                          : (column.options ?? [])
                        ).map((o) => (
                          <option key={o.value} value={o.value}>
                            {o.label}
                          </option>
                        ))}
                      </Select>
                    </label>
                  ) : (
                    <Input
                      label={`Filtrar ${column.header}`}
                      type={
                        column.type === 'number'
                          ? 'number'
                          : column.type === 'date'
                            ? 'date'
                            : 'text'
                      }
                      value={filter.value}
                      onChange={(e) => update(e.target.value)}
                    />
                  )}
                </div>
              );
            })}
          <Button
            variant="ghost"
            onClick={() => {
              setFilters([]);
              resetQuery();
            }}
          >
            Limpiar filtros
          </Button>
        </fieldset>
      )}
      {showColumns && (
        <fieldset id={`${id}-columns`} className="data-grid-panel">
          <legend>Visibilidad y orden de columnas</legend>
          {orderedColumns.map((column, index) => (
            <div className="data-grid-column-option" key={column.field}>
              <label>
                <input
                  type="checkbox"
                  checked={visibleColumns.includes(column)}
                  disabled={
                    column.hideable === false ||
                    (visibleColumns.length === 1 &&
                      visibleColumns.includes(column))
                  }
                  onChange={(e) =>
                    setVisibility({
                      ...visibility,
                      [column.field]: e.target.checked,
                    })
                  }
                />
                {column.header}
              </label>
              <Button
                variant="ghost"
                aria-label={`Mover ${column.header} a la izquierda`}
                disabled={index === 0}
                onClick={() =>
                  moveColumn(column.field, orderedColumns[index - 1]!.field)
                }
              >
                ←
              </Button>
              <Button
                variant="ghost"
                aria-label={`Mover ${column.header} a la derecha`}
                disabled={index === orderedColumns.length - 1}
                onClick={() =>
                  moveColumn(column.field, orderedColumns[index + 1]!.field)
                }
              >
                →
              </Button>
            </div>
          ))}
        </fieldset>
      )}
      {loading && (
        <p role="status" className="data-grid-message">
          Cargando registros…
        </p>
      )}
      {error && (
        <Notice>
          {error}
          {props.onRetry && (
            <Button variant="ghost" onClick={props.onRetry}>
              Reintentar
            </Button>
          )}
        </Notice>
      )}
      {!error && (
        <div
          className="data-grid-scroll"
          ref={layout.container}
          role="region"
          aria-label={`Tabla de ${label}`}
          tabIndex={0}
        >
          <table style={{ width: layout.tableWidth }}>
            <caption className="data-grid-sr-only">{label}</caption>
            <colgroup>
              {hasCheckbox && <col style={{ width: 52 }} />}
              {visibleColumns.map((column, index) => (
                <col
                  key={column.field}
                  style={{ width: layout.widths[index] }}
                />
              ))}
              {hasActions && <col style={{ width: actionWidth }} />}
            </colgroup>
            <thead>
              <tr>
                {hasCheckbox && (
                  <th scope="col">
                    {selectionMode === 'multiple' && selectAll !== 'none' ? (
                      <input
                        type="checkbox"
                        aria-label="Seleccionar página actual"
                        checked={allPageSelected}
                        ref={(element) => {
                          if (element)
                            element.indeterminate =
                              somePageSelected && !allPageSelected;
                        }}
                        disabled={disabled || !selectableIds.length}
                        onChange={(e) =>
                          changeIds(selectableIds, e.target.checked)
                        }
                      />
                    ) : (
                      <span className="data-grid-sr-only">Selección</span>
                    )}
                  </th>
                )}
                {visibleColumns.map((column, columnIndex) => (
                  <th
                    key={column.field}
                    scope="col"
                    aria-sort={
                      sort?.field === column.field
                        ? sort.direction === 'asc'
                          ? 'ascending'
                          : 'descending'
                        : undefined
                    }
                    style={{
                      textAlign: column.align,
                    }}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      const field = dragged.current;
                      if (field) moveColumn(field, column.field);
                      dragged.current = null;
                    }}
                  >
                    <span
                      className="data-grid-heading"
                      draggable
                      onDragStart={(e) => {
                        dragged.current = column.field;
                        e.dataTransfer.setData('text/plain', column.field);
                      }}
                      onDragEnd={() => {
                        dragged.current = null;
                      }}
                    >
                      {column.sortable === false ? (
                        column.header
                      ) : (
                        <button
                          type="button"
                          className="data-grid-sort"
                          aria-label={`Ordenar por ${column.header}`}
                          onClick={() => {
                            setSort(
                              sort?.field !== column.field
                                ? { field: column.field, direction: 'asc' }
                                : sort.direction === 'asc'
                                  ? { field: column.field, direction: 'desc' }
                                  : null,
                            );
                            setPagination({ page: 0, pageSize });
                            anchor.current = null;
                          }}
                        >
                          {column.header}
                          <span aria-hidden="true">
                            {sort?.field === column.field
                              ? sort.direction === 'asc'
                                ? ' ↑'
                                : ' ↓'
                              : ' ↕'}
                          </span>
                        </button>
                      )}
                    </span>
                    {column.resizable !== false && (
                      <ColumnResizeHandle
                        label={column.header}
                        width={layout.widths[columnIndex]!}
                        {...columnBounds(column)}
                        onPreview={(width) =>
                          setResizePreview(
                            width === null
                              ? null
                              : { field: column.field, width },
                          )
                        }
                        onCommit={(width) =>
                          setColumnWidths({
                            ...columnWidths,
                            [column.field]: width,
                          })
                        }
                      />
                    )}
                  </th>
                ))}
                {hasActions && <th scope="col">Acciones</th>}
              </tr>
            </thead>
            <tbody ref={body}>
              {loading && rows.length === 0 && (
                <DataGridSkeletonRows
                  rows={Math.min(5, pageSize)}
                  columns={visibleColumns.length}
                  selection={hasCheckbox}
                  actions={hasActions}
                  rowHeight={Math.max(32, props.rowHeight ?? 48)}
                />
              )}
              {pageRows.map((row, index) => {
                const rowId = getRowId(row);
                const checked = selected(rowId);
                return (
                  <tr
                    key={rowId}
                    className={checked ? 'data-grid-selected' : undefined}
                    aria-selected={
                      selectionMode === 'none' ? undefined : checked
                    }
                    tabIndex={
                      selectionMode !== 'none' && selectOnKeyboard
                        ? 0
                        : undefined
                    }
                    onKeyDown={(e) => rowKeyDown(e, rowId, index)}
                    onMouseDown={(e) => {
                      if (
                        e.shiftKey &&
                        selectOnClick &&
                        selectionMode === 'multiple' &&
                        !(e.target as HTMLElement).closest(
                          'button,input,select,textarea,a,[role="button"],[contenteditable]',
                        )
                      ) {
                        e.preventDefault();
                      }
                    }}
                    onClick={(e) => {
                      if (
                        selectOnClick &&
                        !(e.target as HTMLElement).closest(
                          'button,input,select,textarea,a,[role="button"],[contenteditable]',
                        )
                      )
                        selectRow(rowId, e);
                    }}
                  >
                    {hasCheckbox && (
                      <td>
                        <input
                          type="checkbox"
                          aria-label={`Seleccionar fila ${String(rowId)}`}
                          checked={checked}
                          disabled={disabled || !canSelectId(rowId)}
                          onChange={() => {
                            /* Click handles modifiers and keyboard activation. */
                          }}
                          onClick={(e) => selectRow(rowId, e, true)}
                        />
                      </td>
                    )}
                    {visibleColumns.map((column) => {
                      const value = column.getValue(row);
                      return (
                        <td
                          key={column.field}
                          style={{
                            textAlign: column.align,
                            maxWidth: column.maxWidth,
                          }}
                        >
                          {column.render
                            ? column.render(row)
                            : column.format
                              ? column.format(value, row)
                              : value instanceof Date
                                ? value.toLocaleDateString('es-AR')
                                : typeof value === 'boolean'
                                  ? value
                                    ? 'Sí'
                                    : 'No'
                                  : (value ?? '—')}
                        </td>
                      );
                    })}
                    {hasActions && (
                      <td>
                        <div className="data-grid-actions">
                          {props.rowActions
                            ?.filter((a) => a.visible?.(row) !== false)
                            .map((a) => (
                              <ActionButton
                                key={a.id}
                                label={a.label}
                                icon={a.icon}
                                radius={a.radius}
                                display={a.display}
                                disabled={disabled || a.disabled?.(row)}
                                onClick={() => a.onClick(row)}
                              />
                            ))}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!loading && pageRows.length === 0 && (
            <p role="status" className="data-grid-message">
              {search || filters.some((f) => f.value)
                ? 'No hay resultados para los filtros actuales.'
                : (props.emptyMessage ?? 'No hay registros para mostrar.')}
            </p>
          )}
        </div>
      )}
      <div className="data-grid-footer">
        {selectionMode !== 'none' && (
          <div className="data-grid-actions">
            <span role="status">{selectionContext.count} seleccionados</span>
            {selectionContext.count > 0 && (
              <Button
                variant="ghost"
                onClick={() => {
                  setSelection(emptySelection);
                  anchor.current = null;
                }}
              >
                Limpiar selección
              </Button>
            )}
            {selectionMode === 'multiple' && canSelectDataset && (
              <Button
                variant="ghost"
                disabled={disabled || total === 0}
                onClick={() =>
                  setSelection(
                    remote
                      ? { type: 'all', excludedIds: [], scope }
                      : { type: 'include', ids: processed.map(getRowId) },
                  )
                }
              >
                Seleccionar todos los resultados
              </Button>
            )}
            {props.bulkActions
              ?.filter((a) => a.visible?.(selectionContext) !== false)
              .map((a) => (
                <ActionButton
                  key={a.id}
                  label={a.label}
                  icon={a.icon}
                  radius={a.radius}
                  display={a.display}
                  disabled={
                    disabled ||
                    selectionContext.count === 0 ||
                    a.disabled?.(selectionContext)
                  }
                  onClick={() => a.onClick(selectionContext)}
                />
              ))}
          </div>
        )}
        <nav
          aria-label={`Paginación de ${label}`}
          className="data-grid-pagination"
        >
          <Select
            aria-label="Filas por página"
            value={pageSize}
            onChange={(e) => {
              setPagination({ page: 0, pageSize: Number(e.target.value) });
              anchor.current = null;
            }}
          >
            {pageSizes.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </Select>
          <span>
            {total === 0 ? 0 : page * pageSize + 1}–
            {Math.min((page + 1) * pageSize, total)} de {total}
          </span>
          <Button
            variant="ghost"
            aria-label="Primera página"
            disabled={disabled || page === 0}
            onClick={() => {
              setPagination({ page: 0, pageSize });
              anchor.current = null;
            }}
          >
            «
          </Button>
          <Button
            variant="ghost"
            aria-label="Página anterior"
            disabled={disabled || page === 0}
            onClick={() => {
              setPagination({ page: page - 1, pageSize });
              anchor.current = null;
            }}
          >
            ‹
          </Button>
          <span>
            Página {page + 1} de {lastPage + 1}
          </span>
          <Button
            variant="ghost"
            aria-label="Página siguiente"
            disabled={disabled || page >= lastPage}
            onClick={() => {
              setPagination({ page: page + 1, pageSize });
              anchor.current = null;
            }}
          >
            ›
          </Button>
          <Button
            variant="ghost"
            aria-label="Última página"
            disabled={disabled || page >= lastPage}
            onClick={() => {
              setPagination({ page: lastPage, pageSize });
              anchor.current = null;
            }}
          >
            »
          </Button>
        </nav>
      </div>
    </section>
  );
}
