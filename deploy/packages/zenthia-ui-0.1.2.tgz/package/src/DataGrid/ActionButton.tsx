import { Button } from '../Button';
import type { DataGridActionPresentation } from './types';

export function ActionButton({
  label,
  icon,
  radius,
  display = icon ? 'icon-text' : 'text',
  disabled,
  onClick,
}: DataGridActionPresentation & {
  label: string;
  disabled?: boolean;
  onClick: () => void;
}) {
  const iconOnly = display === 'icon' && Boolean(icon);
  return (
    <Button
      variant="ghost"
      radius={radius}
      className={iconOnly ? 'data-grid-icon-button' : undefined}
      aria-label={label}
      title={iconOnly ? label : undefined}
      disabled={disabled}
      onClick={onClick}
    >
      {display !== 'text' && icon && (
        <span aria-hidden="true" className="data-grid-action-icon">
          {icon}
        </span>
      )}
      {!iconOnly && <span>{label}</span>}
    </Button>
  );
}
