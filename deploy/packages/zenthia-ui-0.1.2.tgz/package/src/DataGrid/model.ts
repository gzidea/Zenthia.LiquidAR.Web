import type {
  DataGridColumn,
  DataGridFilterModel,
  DataGridFilterOperator,
  DataGridSortModel,
  DataGridValue,
} from './types';

const normalize = (value: DataGridValue) =>
  String(value ?? '').toLocaleLowerCase();
const comparable = (value: DataGridValue) =>
  value instanceof Date ? value.getTime() : value;
export function compareValues(a: DataGridValue, b: DataGridValue): number {
  const left = comparable(a);
  const right = comparable(b);
  if (left == null) return right == null ? 0 : -1;
  if (right == null) return 1;
  if (typeof left === 'number' && typeof right === 'number')
    return left - right;
  return String(left).localeCompare(String(right), 'es', {
    numeric: true,
    sensitivity: 'base',
  });
}
export function operatorsFor<T>(
  column: DataGridColumn<T>,
): readonly DataGridFilterOperator[] {
  if (column.filterOperators) return column.filterOperators;
  if (column.type === 'number' || column.type === 'date') {
    const number = (v: DataGridValue) =>
      column.type === 'date'
        ? v instanceof Date
          ? v.getTime()
          : Date.parse(String(v))
        : Number(v);
    return [
      {
        value: 'eq',
        label: 'Igual a',
        test: (v, f) => v != null && number(v) === number(f),
      },
      {
        value: 'gt',
        label: 'Mayor que',
        test: (v, f) => v != null && number(v) > number(f),
      },
      {
        value: 'lt',
        label: 'Menor que',
        test: (v, f) => v != null && number(v) < number(f),
      },
    ];
  }
  if (column.type === 'boolean' || column.type === 'select') {
    return [
      {
        value: 'eq',
        label: 'Igual a',
        test: (v, f) => v != null && String(v) === f,
      },
    ];
  }
  return [
    {
      value: 'contains',
      label: 'Contiene',
      test: (v, f) => normalize(v).includes(normalize(f)),
    },
    {
      value: 'eq',
      label: 'Igual a',
      test: (v, f) => normalize(v) === normalize(f),
    },
    {
      value: 'startsWith',
      label: 'Comienza con',
      test: (v, f) => normalize(v).startsWith(normalize(f)),
    },
  ];
}
export function processRows<T>(
  rows: readonly T[],
  columns: readonly DataGridColumn<T>[],
  search: string,
  filters: DataGridFilterModel,
  sort: DataGridSortModel,
): T[] {
  const text = normalize(search.trim());
  const result = rows.filter(
    (row) =>
      (!text ||
        columns.some(
          (c) =>
            c.searchable !== false && normalize(c.getValue(row)).includes(text),
        )) &&
      filters.every((filter) => {
        if (!filter.value) return true;
        const column = columns.find((c) => c.field === filter.field);
        if (!column || column.filterable === false) return true;
        const operator = operatorsFor(column).find(
          (o) => o.value === filter.operator,
        );
        return operator
          ? operator.test(column.getValue(row), filter.value)
          : false;
      }),
  );
  const column = columns.find(
    (c) => c.field === sort?.field && c.sortable !== false,
  );
  if (column && sort) {
    const getValue = column.getSortValue ?? column.getValue;
    result.sort(
      (a, b) =>
        (column.compare ?? compareValues)(getValue(a), getValue(b)) *
        (sort.direction === 'asc' ? 1 : -1),
    );
  }
  return result;
}
