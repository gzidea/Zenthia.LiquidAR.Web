import { useRef } from 'react';

interface Props {
  label: string;
  width: number;
  min: number;
  max: number;
  onPreview: (width: number | null) => void;
  onCommit: (width: number) => void;
}

export function ColumnResizeHandle({
  label,
  width,
  min,
  max,
  onPreview,
  onCommit,
}: Props) {
  const drag = useRef<{
    pointer: number;
    x: number;
    start: number;
    width: number;
  } | null>(null);
  const clamp = (value: number) =>
    Math.round(Math.max(min, Math.min(max, value)));
  function cancel() {
    if (!drag.current) return;
    drag.current = null;
    onPreview(null);
  }
  return (
    <span
      className="data-grid-resize"
      role="separator"
      aria-orientation="vertical"
      aria-label={`Ancho de ${label}`}
      aria-valuenow={Math.round(width)}
      aria-valuemin={min}
      aria-valuemax={max}
      tabIndex={0}
      title={`Cambiar ancho de ${label}: arrastrar o usar flechas`}
      onClick={(event) => event.stopPropagation()}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        event.preventDefault();
        event.stopPropagation();
        event.currentTarget.focus();
        event.currentTarget.setPointerCapture(event.pointerId);
        drag.current = {
          pointer: event.pointerId,
          x: event.clientX,
          start: width,
          width,
        };
      }}
      onPointerMove={(event) => {
        const current = drag.current;
        if (!current || current.pointer !== event.pointerId) return;
        current.width = clamp(current.start + event.clientX - current.x);
        onPreview(current.width);
      }}
      onPointerUp={(event) => {
        const current = drag.current;
        if (!current || current.pointer !== event.pointerId) return;
        drag.current = null;
        onPreview(null);
        if (current.width !== current.start) onCommit(current.width);
        event.currentTarget.releasePointerCapture(event.pointerId);
      }}
      onPointerCancel={cancel}
      onLostPointerCapture={cancel}
      onKeyDown={(event) => {
        if (event.key === 'Escape') {
          cancel();
          return;
        }
        const next =
          event.key === 'ArrowLeft'
            ? width - 10
            : event.key === 'ArrowRight'
              ? width + 10
              : event.key === 'Home'
                ? min
                : event.key === 'End'
                  ? max
                  : null;
        if (next === null || drag.current) return;
        event.preventDefault();
        event.stopPropagation();
        onCommit(clamp(next));
      }}
    />
  );
}
