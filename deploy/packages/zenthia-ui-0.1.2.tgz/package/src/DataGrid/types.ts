import type { ReactNode } from 'react';
import type { ButtonProps } from '../Button';

export type DataGridRowId = string | number;
export type DataGridValue = string | number | boolean | Date | null | undefined;
export type DataGridSortModel = {
  field: string;
  direction: 'asc' | 'desc';
} | null;
export interface DataGridPaginationModel {
  page: number;
  pageSize: number;
}
export interface DataGridFilter {
  field: string;
  operator: string;
  value: string;
}
export type DataGridFilterModel = readonly DataGridFilter[];
export type DataGridColumnWidthsModel = Readonly<Record<string, number>>;
export type DataGridSelectionModel =
  | { type: 'include'; ids: readonly DataGridRowId[] }
  | { type: 'all'; excludedIds: readonly DataGridRowId[]; scope: string };

export interface DataGridFilterOperator {
  value: string;
  label: string;
  test: (value: DataGridValue, filter: string) => boolean;
}
export interface DataGridColumn<T> {
  field: string;
  header: string;
  getValue: (row: T) => DataGridValue;
  width?: number;
  minWidth?: number;
  maxWidth?: number;
  resizable?: boolean;
  align?: 'left' | 'center' | 'right';
  type?: 'text' | 'number' | 'date' | 'boolean' | 'select';
  sortable?: boolean;
  filterable?: boolean;
  searchable?: boolean;
  hideable?: boolean;
  initiallyHidden?: boolean;
  render?: (row: T) => ReactNode;
  format?: (value: DataGridValue, row: T) => string;
  getSortValue?: (row: T) => DataGridValue;
  compare?: (a: DataGridValue, b: DataGridValue) => number;
  options?: readonly { value: string; label: string }[];
  filterOperators?: readonly DataGridFilterOperator[];
  renderFilter?: (
    filter: DataGridFilter,
    onChange: (value: string) => void,
  ) => ReactNode;
}
export interface DataGridActionPresentation {
  radius?: ButtonProps['radius'];
  icon?: ReactNode;
  display?: 'text' | 'icon' | 'icon-text';
}
export interface DataGridAction<T> extends DataGridActionPresentation {
  id: string;
  label: string;
  visible?: (row: T) => boolean;
  disabled?: (row: T) => boolean;
  onClick: (row: T) => void;
}
export interface DataGridGlobalAction extends DataGridActionPresentation {
  id: string;
  label: string;
  visible?: boolean;
  disabled?: boolean;
  onClick: () => void;
}
export interface DataGridSelectionContext<T> {
  model: DataGridSelectionModel;
  /** Only selected rows currently supplied through rows; never the complete remote dataset. */
  loadedRows: readonly T[];
  count: number;
}
export type DataGridBulkAction<T> = DataGridAction<DataGridSelectionContext<T>>;
export interface DataGridState {
  pagination: DataGridPaginationModel;
  sort: DataGridSortModel;
  filters: DataGridFilterModel;
  search: string;
  selection: DataGridSelectionModel;
  columnVisibility: Readonly<Record<string, boolean>>;
  columnOrder: readonly string[];
  columnWidths: DataGridColumnWidthsModel;
}

interface CommonProps<T> {
  showSearch?: boolean;
  showFilterButton?: boolean;
  searchDisabled?: boolean;
  filterButtonDisabled?: boolean;
  searchUnavailableReason?: string;
  filtersUnavailableReason?: string;
  label: string;
  rows: readonly T[];
  columns: readonly DataGridColumn<T>[];
  getRowId: (row: T) => DataGridRowId;
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  emptyMessage?: string;
  pageSizeOptions?: readonly number[];
  /** Minimum row height in pixels; content may grow to remain accessible. */
  rowHeight?: number;
  initialState?: Partial<DataGridState>;
  paginationModel?: DataGridPaginationModel;
  onPaginationModelChange?: (model: DataGridPaginationModel) => void;
  sortModel?: DataGridSortModel;
  onSortModelChange?: (model: DataGridSortModel) => void;
  filterModel?: DataGridFilterModel;
  onFilterModelChange?: (model: DataGridFilterModel) => void;
  search?: string;
  onSearchChange?: (value: string) => void;
  selectionMode?: 'none' | 'single' | 'multiple';
  /** Retain explicit selection across search/filter/sort changes on a complete client dataset. */
  keepSelectionOnQueryChange?: boolean;
  checkboxSelection?: boolean;
  /** Excludes unavailable rows from individual, range and page selection. */
  isRowSelectable?: (row: T) => boolean;
  selectOnClick?: boolean;
  selectOnKeyboard?: boolean;
  selectAll?: 'page' | 'dataset' | 'none';
  /** Stable identity of the remote query (including its filters), required to select its entire dataset. */
  selectionScope?: string;
  selectionModel?: DataGridSelectionModel;
  onSelectionModelChange?: (model: DataGridSelectionModel) => void;
  columnVisibilityModel?: Readonly<Record<string, boolean>>;
  onColumnVisibilityModelChange?: (
    model: Readonly<Record<string, boolean>>,
  ) => void;
  columnOrder?: readonly string[];
  onColumnOrderChange?: (fields: readonly string[]) => void;
  columnWidthsModel?: DataGridColumnWidthsModel;
  onColumnWidthsModelChange?: (widths: DataGridColumnWidthsModel) => void;
  rowActions?: readonly DataGridAction<T>[];
  globalActions?: readonly DataGridGlobalAction[];
  bulkActions?: readonly DataGridBulkAction<T>[];
}
export type DataGridProps<T> = CommonProps<T> &
  (
    | { processingMode?: 'client'; rowCount?: never }
    | {
        processingMode: 'server';
        rowCount: number;
        paginationModel: DataGridPaginationModel;
        onPaginationModelChange: (model: DataGridPaginationModel) => void;
      }
  );
