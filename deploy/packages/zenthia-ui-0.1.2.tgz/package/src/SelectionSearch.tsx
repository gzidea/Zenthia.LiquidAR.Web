import { Input } from './Input';
import { Button } from './Button';
import './selection-search.css';
export function SelectionSearch({
  label,
  value,
  onChange,
  placeholder = 'Código o descripción',
  disabled = false,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <div className="selection-search">
      <Input
        label={label}
        type="search"
        value={value}
        placeholder={placeholder}
        maxLength={255}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
      />
      <Button
        type="button"
        variant="ghost"
        disabled={disabled || value === ''}
        onClick={() => onChange('')}
      >
        Limpiar búsqueda
      </Button>
    </div>
  );
}
export function matchesSelection(text: string, search: string) {
  const normalize = (value: string) =>
    value
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLocaleLowerCase('es')
      .trim();
  return normalize(text).includes(normalize(search));
}
