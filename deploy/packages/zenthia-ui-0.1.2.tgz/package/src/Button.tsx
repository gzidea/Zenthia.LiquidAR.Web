import type { ButtonHTMLAttributes, CSSProperties } from 'react';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  busy?: boolean;
  variant?: 'primary' | 'ghost';
  /** Pixels for numbers, or a CSS value. Omit to inherit --button-radius from the theme. */
  radius?: CSSProperties['borderRadius'];
}
export function Button({
  children,
  busy = false,
  variant = 'primary',
  disabled,
  className = '',
  type = 'button',
  radius,
  style,
  ...props
}: ButtonProps) {
  return (
    <button
      {...props}
      type={type}
      style={radius === undefined ? style : { ...style, borderRadius: radius }}
      disabled={disabled || busy}
      aria-busy={busy || undefined}
      className={`button button-${variant} ${className}`}
    >
      {children}
    </button>
  );
}
