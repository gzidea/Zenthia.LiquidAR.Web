import type { ReactNode } from 'react';
export function AuthCard({
  title,
  subtitle,
  badge,
  kicker,
  children,
}: {
  title: string;
  subtitle: string;
  badge: string;
  kicker: string;
  children: ReactNode;
}) {
  return (
    <section className="auth-card" aria-labelledby="auth-title">
      <div className="status-badge">{badge}</div>
      <header className="card-head">
        <p className="kicker">{kicker}</p>
        <h1 id="auth-title" tabIndex={-1}>
          {title}
        </h1>
        <p className="subtitle">{subtitle}</p>
      </header>
      {children}
    </section>
  );
}
