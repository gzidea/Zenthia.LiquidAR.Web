import type { CSSProperties } from 'react';
import { Skeleton, skeletonCount } from './Skeleton';
import { SkeletonActions } from './SkeletonActions';
import type { FormSkeletonField, FormSkeletonProps } from './types';

export function FormSkeleton({
  fields = 6,
  columns = 1,
  gap = 'var(--space-4)',
  actions = true,
  label = 'Cargando formulario…',
  animation = 'pulse',
  className = '',
  style,
}: FormSkeletonProps) {
  const items: readonly FormSkeletonField[] =
    typeof fields === 'number'
      ? Array.from({ length: skeletonCount(fields, 6) }, () => ({}))
      : fields;
  return (
    <div className={`form-skeleton ${className}`} style={style}>
      <span role="status" className="skeleton-sr-only">
        {label}
      </span>
      <div aria-busy="true" aria-label={label} role="group">
        <div
          className="form-skeleton-fields"
          aria-hidden="true"
          style={{ '--skeleton-columns': columns, gap } as CSSProperties}
        >
          {items.map(({ kind = 'input', fullWidth, width, height }, index) => (
            <div
              key={index}
              className={`form-skeleton-field${fullWidth || kind === 'section' ? ' form-skeleton-full' : ''} form-skeleton-${kind}`}
            >
              {kind === 'section' ? (
                <Skeleton
                  width={width ?? '40%'}
                  height={height ?? 20}
                  animation={animation}
                />
              ) : kind === 'checkbox' ? (
                <>
                  <Skeleton
                    variant="rounded"
                    width={18}
                    height={18}
                    animation={animation}
                  />
                  <Skeleton width={width ?? '65%'} animation={animation} />
                </>
              ) : (
                <>
                  <Skeleton width="40%" height={12} animation={animation} />
                  <div className="form-skeleton-control">
                    <Skeleton
                      variant="rounded"
                      width={width ?? '100%'}
                      height={height ?? (kind === 'textarea' ? 100 : 46)}
                      animation={animation}
                    />
                    {kind === 'select' && (
                      <span className="form-skeleton-chevron" />
                    )}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
        {actions && (
          <SkeletonActions
            animation={animation}
            {...(typeof actions === 'object' ? actions : {})}
          />
        )}
      </div>
    </div>
  );
}
