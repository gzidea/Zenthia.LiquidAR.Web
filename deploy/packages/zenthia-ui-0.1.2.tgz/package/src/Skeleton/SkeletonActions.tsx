import { Skeleton, skeletonCount } from './Skeleton';
import type { SkeletonActionsProps } from './types';

export function SkeletonActions({
  count = 2,
  width = 104,
  height = 46,
  gap = 'var(--space-2)',
  align = 'end',
  animation = 'pulse',
  className = '',
  style,
}: SkeletonActionsProps) {
  return (
    <div
      className={`skeleton-actions ${className}`}
      aria-hidden="true"
      style={{
        gap,
        justifyContent:
          align === 'start'
            ? 'flex-start'
            : align === 'end'
              ? 'flex-end'
              : 'center',
        ...style,
      }}
    >
      {Array.from({ length: skeletonCount(count, 2) }, (_, index) => (
        <Skeleton
          key={index}
          variant="rounded"
          width={width}
          height={height}
          animation={animation}
        />
      ))}
    </div>
  );
}
