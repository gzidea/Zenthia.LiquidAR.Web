import type { SkeletonProps } from './types';
import './skeleton.css';

// Counts describe placeholders, never data totals. Normalize invalid values safely.
export function skeletonCount(value: number, fallback: number) {
  return Number.isFinite(value) ? Math.max(0, Math.floor(value)) : fallback;
}

export function Skeleton({
  variant = 'text',
  width,
  height,
  count = 1,
  gap = 'var(--space-2)',
  animation = 'pulse',
  className = '',
  style,
}: SkeletonProps) {
  return (
    <span
      className={`skeleton-stack ${className}`}
      aria-hidden="true"
      style={{ gap, ...style }}
    >
      {Array.from({ length: skeletonCount(count, 1) }, (_, index) => (
        <span
          key={index}
          className={`skeleton-block skeleton-${variant}${animation ? ' skeleton-pulse' : ''}`}
          style={{ width, height }}
        />
      ))}
    </span>
  );
}
