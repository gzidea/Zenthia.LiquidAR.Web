import { Skeleton, skeletonCount } from './Skeleton';
import { SkeletonActions } from './SkeletonActions';
import type { DataGridSkeletonRowsProps } from './types';

/** Decorative rows for a consumer-owned table/tbody and loading announcement. */
export function DataGridSkeletonRows({
  rows = 5,
  columns = 4,
  selection = false,
  actions = false,
  rowHeight = 48,
  animation = 'pulse',
}: DataGridSkeletonRowsProps) {
  return Array.from({ length: skeletonCount(rows, 5) }, (_, row) => (
    <tr
      key={row}
      aria-hidden="true"
      className="skeleton-grid-row"
      style={{ height: rowHeight }}
    >
      {selection && (
        <td>
          <Skeleton
            variant="rounded"
            width={18}
            height={18}
            animation={animation}
          />
        </td>
      )}
      {Array.from({ length: skeletonCount(columns, 4) }, (_, column) => (
        <td key={column}>
          <Skeleton width={row % 2 ? '65%' : '80%'} animation={animation} />
        </td>
      ))}
      {actions && (
        <td>
          <SkeletonActions
            count={2}
            width={24}
            height={24}
            align="start"
            animation={animation}
          />
        </td>
      )}
    </tr>
  ));
}
