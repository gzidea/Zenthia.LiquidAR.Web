import type { CSSProperties } from 'react';

export type SkeletonVariant = 'text' | 'rectangular' | 'circular' | 'rounded';
export type SkeletonDimension = CSSProperties['width'];
export type SkeletonAnimation = 'pulse' | false;
export interface SkeletonPresentation {
  animation?: SkeletonAnimation;
  className?: string;
  style?: CSSProperties;
}
export interface SkeletonProps extends SkeletonPresentation {
  variant?: SkeletonVariant;
  width?: SkeletonDimension;
  height?: CSSProperties['height'];
  count?: number;
  gap?: CSSProperties['gap'];
}
export interface SkeletonActionsProps extends SkeletonPresentation {
  count?: number;
  width?: SkeletonDimension;
  height?: CSSProperties['height'];
  gap?: CSSProperties['gap'];
  align?: 'start' | 'center' | 'end';
}
export interface FormSkeletonField {
  kind?: 'input' | 'select' | 'textarea' | 'checkbox' | 'section';
  /** Occupy the complete row regardless of the responsive column count. */
  fullWidth?: boolean;
  width?: SkeletonDimension;
  height?: CSSProperties['height'];
}
export interface FormSkeletonProps extends SkeletonPresentation {
  fields?: number | readonly FormSkeletonField[];
  columns?: 1 | 2 | 3 | 4;
  gap?: CSSProperties['gap'];
  actions?: boolean | SkeletonActionsProps;
  label?: string;
}
export interface DataGridSkeletonRowsProps {
  rows?: number;
  columns?: number;
  selection?: boolean;
  actions?: boolean;
  rowHeight?: number;
  animation?: SkeletonAnimation;
}
export interface DataGridSkeletonProps
  extends DataGridSkeletonRowsProps, SkeletonPresentation {
  /** CSS widths for data columns only; omitted entries share remaining space. */
  columnWidths?: readonly SkeletonDimension[];
  header?: boolean;
  label?: string;
}
