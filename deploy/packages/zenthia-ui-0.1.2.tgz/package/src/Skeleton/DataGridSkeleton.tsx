import { Skeleton, skeletonCount } from './Skeleton';
import { DataGridSkeletonRows } from './DataGridSkeletonRows';
import type { DataGridSkeletonProps } from './types';

export function DataGridSkeleton({
  rows = 5,
  columns = 4,
  columnWidths = [],
  selection = false,
  actions = false,
  header = true,
  rowHeight = 48,
  label = 'Cargando registros…',
  animation = 'pulse',
  className = '',
  style,
}: DataGridSkeletonProps) {
  const dataColumns = Array.from({ length: skeletonCount(columns, 4) });
  return (
    <div className={`data-grid-skeleton ${className}`} style={style}>
      <span role="status" className="skeleton-sr-only">
        {label}
      </span>
      <div
        role="group"
        aria-label={label}
        aria-busy="true"
        className="skeleton-grid-scroll"
      >
        <table aria-hidden="true">
          <colgroup>
            {selection && <col style={{ width: 52 }} />}
            {dataColumns.map((_, index) => (
              <col key={index} style={{ width: columnWidths[index] }} />
            ))}
            {actions && <col style={{ width: 120 }} />}
          </colgroup>
          {header && (
            <thead>
              <tr>
                {selection && (
                  <th>
                    <Skeleton
                      variant="rounded"
                      width={18}
                      height={18}
                      animation={animation}
                    />
                  </th>
                )}
                {dataColumns.map((_, index) => (
                  <th key={index}>
                    <Skeleton width="60%" animation={animation} />
                  </th>
                ))}
                {actions && (
                  <th>
                    <Skeleton width="70%" animation={animation} />
                  </th>
                )}
              </tr>
            </thead>
          )}
          <tbody>
            <DataGridSkeletonRows
              {...{ rows, columns, selection, actions, rowHeight, animation }}
            />
          </tbody>
        </table>
      </div>
    </div>
  );
}
