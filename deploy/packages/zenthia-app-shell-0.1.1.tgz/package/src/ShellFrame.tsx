import type { ReactNode } from 'react';
export function ShellFrame({
  header,
  navigation,
  footer,
  children,
  sidebarOpen,
  sidebarCollapsed,
}: {
  header: ReactNode;
  navigation: ReactNode;
  footer?: ReactNode;
  children: ReactNode;
  sidebarOpen: boolean;
  sidebarCollapsed: boolean;
}) {
  return (
    <div className={`app-shell ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
      <header className="navbar">{header}</header>
      <aside
        className={`sidebar ${sidebarOpen ? 'is-open' : ''}`}
        id="app-sidebar"
      >
        <nav aria-label="Navegación principal">{navigation}</nav>
        {footer}
      </aside>
      <main className="main-content" id="main-content">
        {children}
      </main>
    </div>
  );
}
