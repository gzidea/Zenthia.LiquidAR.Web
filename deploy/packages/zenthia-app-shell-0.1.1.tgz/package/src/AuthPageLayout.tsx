import type { ReactNode } from 'react';

export function AuthPageLayout({
  brand,
  appName,
  children,
}: {
  brand: ReactNode;
  appName: string;
  children: ReactNode;
}) {
  return (
    <div className="auth-layout">
      <header className="auth-topbar">{brand}</header>
      <main id="main-content" className="auth-stage">
        <div className="auth-column">{children}</div>
      </main>
      <footer className="auth-footer">
        {appName} <span aria-hidden="true">/</span> Un espacio para tu trabajo.
      </footer>
    </div>
  );
}
