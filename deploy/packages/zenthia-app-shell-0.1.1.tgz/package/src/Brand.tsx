import type { ReactNode } from 'react';
export function Brand({ name, label }: { name: ReactNode; label: string }) {
  return (
    <div className="brand" aria-label={label}>
      <span className="brand-company">Zenthia</span>
      <span>
        {name}
        <span className="brand-web">.Web</span>
      </span>
    </div>
  );
}
